package StepDefinitions;

import Pages.*;
import Utilities.Driver;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class DeliveryJourneyStepDefinition {

    LandingPage landingPage = new LandingPage();
    ProductScreenPage productScreenPage = new ProductScreenPage();
    SearchResultsPage searchResultsPage = new SearchResultsPage();
    TrolleyBagPage trolleyBagPage = new TrolleyBagPage();
    DeliveryPage deliveryPage = new DeliveryPage();


    @When("user enters email address")
    public void user_enters_email_address() {
        deliveryPage.emailField.sendKeys("internet@internet.com");
    }

    @When("user clicks continue securely button")
    public void user_clicks_continue_securely_button() {
        deliveryPage.continueSecurely.click();
    }

    @When("user clicks continue without signing in")
    public void user_clicks_continue_without_signing_in() {
        deliveryPage.continueWithoutSigningIn.click();
    }

    @When("user clicks select a store and clicks continue")
    public void user_clicks_select_a_store_and_clicks_continue() {
        deliveryPage.collectFromStore.click();
        deliveryPage.continueDeliveryButton.click();
    }

    @When("user types in the store postcode")
    public void user_types_in_the_store_postcode() {
        deliveryPage.postcodeAddressField.sendKeys("m13 9yj");

    }

    @When("user selects show nearby stores")
    public void user_selects_show_nearby_stores() {
        deliveryPage.showNearestStores.click();
    }

    @When("user selects a store option and clicks continue")
    public void user_selects_a_store_option_and_clicks_continue() {
        deliveryPage.nisaLocalStore.click();
        deliveryPage.continueBttn2.click();
    }

    @When("user enters contactNumber and clicks continue to payment")
    public void user_enters_contact_number_and_clicks_continue_to_payment() {
        deliveryPage.contactNumberField.sendKeys("07123456789");
        deliveryPage.continueToPayment.click();
    }

    @Then("user should be taken to payment accordion")
    public void user_should_be_taken_to_payment_accordion() {
        Assert.assertTrue(Driver.get().getTitle().contains("Checkout | Billing Details"));
    }


}
