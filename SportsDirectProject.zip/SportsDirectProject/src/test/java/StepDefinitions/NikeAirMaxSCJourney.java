package StepDefinitions;

import Pages.LandingPage;
import Pages.ProductScreenPage;
import Pages.SearchResultsPage;
import Pages.TrolleyBagPage;
import Utilities.Driver;
import Utilities.PropertiesReader;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.Keys;


import java.util.concurrent.TimeUnit;

public class NikeAirMaxSCJourney {


    LandingPage landingPage = new LandingPage();
    SearchResultsPage searchResultsPage = new SearchResultsPage();
    ProductScreenPage productScreenPage = new ProductScreenPage();
    TrolleyBagPage trolleyBagPage = new TrolleyBagPage();


    @Given("User is on sports direct landing page")
    public void user_is_on_sports_direct_landing_page() throws InterruptedException {
        Driver.get().get(PropertiesReader.get("url"));
        Thread.sleep(1000);
        Driver.get().manage().window().maximize();
        Assert.assertTrue(Driver.get().getTitle().contains("SportsDirect.com – The UK’s No 1 Sports Retailer"));
        Driver.get().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        landingPage.acceptCookies.click();
    }

    @Given("User searches for Nike shoes")
    public void user_searches_for_nike_shoes() {
        landingPage.searchBox.sendKeys("Nike trainers");
        landingPage.searchLogo.click();
    }

    @And("user filters down to select item on search results screen")
    public void user_filters_down_to_select_item_on_search_results_screen() {
        searchResultsPage.menCheckBox.click();
       // searchResultsPage.toggleViewSize.click();
        searchResultsPage.shoeSize9.click();
        searchResultsPage.nikeBrand.click();
        searchResultsPage.sortByDropDown.click();
        searchResultsPage.lowToHighFilterOption.click();
        searchResultsPage.selectResultPage2.click();
    }

    @And("user adds product to trolley")
    public void user_adds_product_to_trolley() {
        productScreenPage.shoeSizeSelection.click();
        //nikeAirMaxProductScreen.shoeQuantity.click();
        for (int a=0; a<3; a++)
        {
            productScreenPage.shoeQuantity.sendKeys(Keys.ADD);
        }
        productScreenPage.shoeQuantity.sendKeys(Keys.ENTER);
        productScreenPage.addToBag.click();
        productScreenPage.viewBag.click();
    }

    @When("user updates the cart and proceeds to checkout")
    public void user_updates_the_cart_and_proceeds_to_checkout() {
        for (int h=0; h<2; h++)
        {
            trolleyBagPage.reduceOrderQuantity.sendKeys(Keys.ADD);
        }
        trolleyBagPage.reduceOrderQuantity.sendKeys(Keys.ENTER);

    }

    @Then("user should be directed to secure login screen")
    public void user_should_be_directed_to_secure_login_screen() {
        trolleyBagPage.continueSecurelyButton.click();
    }




}
