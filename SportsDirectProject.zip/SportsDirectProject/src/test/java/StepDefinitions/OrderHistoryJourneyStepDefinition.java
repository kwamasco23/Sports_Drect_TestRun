package StepDefinitions;

import Pages.AccountPage;
import Pages.LandingPage;
import Pages.SignInPage;
import Utilities.Driver;
import Utilities.PropertiesReader;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

import java.util.concurrent.TimeUnit;

public class OrderHistoryJourneyStepDefinition {

    public LandingPage landingPage = new LandingPage();
    public AccountPage accountPage = new AccountPage();
    public SignInPage signInPage = new SignInPage();

//    @Given("User lands on Sports Direct landing page")
//    public void user_lands_on_sports_direct_landing_page() throws InterruptedException {
//        Driver.get().get(PropertiesReader.get("url"));
//        Thread.sleep(1000);
//        landingPage.acceptCookies.click();
//        Driver.get().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//        Driver.get().manage().window().maximize();
//        Assert.assertTrue(Driver.get().getTitle().contains("SportsDirect.com – The UK’s No 1 Sports Retailer"));
////        Thread.sleep(1000);
//    }

    @Given("User clicks on login account icon")
    public void user_clicks_on_login_account_icon() {
        landingPage.signInLink.click();
    }

    @Given("User logs in to account successfully")
    public void user_logs_in_to_account_successfully() {
        Driver.get().manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
        signInPage.emailAddress.sendKeys("");
        Driver.get().manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
        signInPage.password.sendKeys("");
        signInPage.signInButton.click();

    }

    @When("User clicks on View More Details link")
    public void user_clicks_on_view_more_details_link() throws InterruptedException {
        accountPage.accountICON.click();
        Thread.sleep(1000);
        accountPage.orderHistory.click();
        accountPage.viewMoreDetails.click();
    }

    @Then("User should see details of order")
    public void user_should_see_details_of_order() {

    }

    @When("user clicks on Back to Order history link")
    public void user_clicks_on_back_to_order_history_link() {
        accountPage.back2HistoryButton.click();
    }

    @Then("User should be returned to Order History screen where the list of historic orders will be displayed")
    public void user_should_be_returned_to_order_history_screen_where_the_list_of_historic_orders_will_be_displayed() {
        Assert.assertTrue(Driver.get().getTitle().contains("SportsDirect.com > Account Information > Order History Summary"));
    }

}
