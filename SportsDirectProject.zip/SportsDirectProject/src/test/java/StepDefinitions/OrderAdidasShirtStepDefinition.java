package StepDefinitions;

import Pages.LandingPage;
import Pages.ProductScreenPage;
import Pages.SearchResultsPage;
import Pages.TrolleyBagPage;
import Utilities.Driver;
import Utilities.PropertiesReader;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.Keys;

import java.util.concurrent.TimeUnit;

public class OrderAdidasShirtStepDefinition {

    LandingPage landingPage = new LandingPage();
    SearchResultsPage searchResultsPage = new SearchResultsPage();
    ProductScreenPage productScreenPage = new ProductScreenPage();
    TrolleyBagPage trolleyBagPage = new TrolleyBagPage();


    @Given("User lands on Sports Direct landing page")
    public void user_lands_on_sports_direct_landing_page() throws InterruptedException {
        Driver.get().get(PropertiesReader.get("url"));
        Thread.sleep(1000);
        landingPage.acceptCookies.click();
        Driver.get().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Driver.get().manage().window().maximize();
        Assert.assertTrue(Driver.get().getTitle().contains("SportsDirect.com – The UK’s No 1 Sports Retailer"));
        Thread.sleep(1000);
    }

    @Given("User searches for adult Adidas tshirt")
    public void user_searches_for_adult_adidas_tshirt() throws InterruptedException {
        landingPage.searchBox.sendKeys("adidas tshirt");
        Thread.sleep(1200);
        for (int u=1; u<2; u++)
        {
            landingPage.searchBox.sendKeys(Keys.ARROW_DOWN);
        }
        landingPage.searchBox.sendKeys(Keys.ENTER);
        Thread.sleep(1500);
    }

    @Given("User filters the correct product on search screen")
    public void user_filters_the_correct_product_on_search_screen() {
        searchResultsPage.toggleViewSize.click();
        searchResultsPage.menCheckBox.click();
     //   searchResultsPage.adidasCheckBox.click();
        searchResultsPage.tShirtCheckBox.click();
        searchResultsPage.sortByDropDown.click();
        for (int l=0; l<4; l++)
        {
            searchResultsPage.sortByDropDown.sendKeys(Keys.ARROW_DOWN);
        }
        searchResultsPage.sortByDropDown.sendKeys(Keys.ENTER);
   searchResultsPage.adidasTShirtChosen.click();

    }

    @When("User adds product to cart and selects checkout")
    public void user_adds_product_to_cart_and_selects_checkout() throws InterruptedException {
        trolleyBagPage.shirtSizeLARGE.click();
        Thread.sleep(1200);
        productScreenPage.addToBag.click();
        Thread.sleep(1200);
        productScreenPage.viewBag.click();
        Thread.sleep(1200);
    }

    @Then("User should be directed to login screen")
    public void user_should_be_directed_to_login_screen() {
        trolleyBagPage.continueSecurelyButton.click();
    }




}
