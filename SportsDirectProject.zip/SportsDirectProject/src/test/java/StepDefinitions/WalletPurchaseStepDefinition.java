package StepDefinitions;

import Pages.LandingPage;
import Pages.ProductScreenPage;
import Pages.SearchResultsPage;
import Pages.TrolleyBagPage;
import Utilities.Driver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.Keys;

import java.util.concurrent.TimeUnit;

public class WalletPurchaseStepDefinition {

    LandingPage landingPage = new LandingPage();
    SearchResultsPage searchResultsPage = new SearchResultsPage();
    ProductScreenPage productScreenPage = new ProductScreenPage();
    TrolleyBagPage trolleyBagPage = new TrolleyBagPage();


    // In this step, we are landing on the landing page, clicking into search bar,
    // keying in keyword 'wallet', selecting from the drop down auto suggestive options
    // and clicking enter to initiate our search
    @Given("user clicks on search bar and searches for men's wallet")
    public void user_clicks_on_search_bar_and_searches_for_men_s_wallet() {
        Driver.get().manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
        landingPage.searchBox.click();
        Driver.get().manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
        landingPage.searchBox.sendKeys("wallet");
        Driver.get().manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
        for (int ff=0; ff<4; ff++)
        {
            landingPage.searchBox.sendKeys(Keys.ARROW_DOWN);
        }
        Driver.get().manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
        landingPage.searchBox.sendKeys(Keys.ENTER);
    }

    // using the filter on the search screen, we are clicking on to sortby option, we are then
    // selecting hemlock wallet, on the product screen we are adding quantity, then reducing the
    // quantity and finally we return to the wallet search screen
    @Given("user filters down search results and selects a wallet")
    public void user_filters_down_search_results_and_selects_a_wallet() throws InterruptedException {
        Driver.get().manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
        searchResultsPage.sortByDropDown.click();
        Thread.sleep(3000);
        searchResultsPage.hemlockWallet.click();
        productScreenPage.walletQuantityAddButton.click();
        Thread.sleep(3500);
        productScreenPage.getWalletQuantityRemoveButton.click();
        Driver.get().manage().timeouts().implicitlyWait(2500, TimeUnit.SECONDS);
        productScreenPage.ReturnToSearchResults.click();
    }

    // Given we've returned back to the wallet search screen, we now select our filters to 'mens'
    // we then select a different type of wallet brand. On the product screen we click into the quantity
    // field, clear the field, key in the value we want in quantity, add to bag and eventually
    // proceed to 'view bag' screen
    //Notice that I repeatedly add 'Thread.sleep'?? This is to slow down the web driver which runs too quickly
    @When("user selects applicable color and quantity on wallet screen and selects add to trolley and View bag")
    public void user_selects_applicable_color_and_quantity_on_wallet_screen_and_selects_add_to_trolley_and_view_bag() throws InterruptedException {
        searchResultsPage.menCheckBox.click();
        Thread.sleep(3500);
        productScreenPage.CCOpenHolderWallet.click();
        Thread.sleep(3500);
        productScreenPage.quantityTypeField.click();
        Thread.sleep(3500);
        productScreenPage.quantityTypeField.clear();
        Thread.sleep(3500);
        productScreenPage.quantityTypeField.sendKeys("3");
        Thread.sleep(3500);
        productScreenPage.addToBag.click();
        Thread.sleep(3500);
        productScreenPage.viewBag.click();
        
    }

    //lastly this is to ensure that we are on the correct screen. So we conclude here by
    // adding the page title
    @Then("user should be able to confirm they are on the correct screen using webdriver assertion")
    public void user_should_be_able_to_confirm_they_are_on_the_correct_screen_using_webdriver_assertion() {
        Assert.assertTrue(Driver.get().getTitle().contains("SportsDirect.com > Cart"));
    }

}
