package StepDefinitions;

import Utilities.Driver;
import io.cucumber.java.After;
import org.junit.Before;

import java.util.concurrent.TimeUnit;

public class Hooks {

    @Before
    public void Before()
    {
        Driver.get().manage().window().maximize();
        Driver.get().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @After
    public void After()
    {
        Driver.get().quit();

    }
}
