package StepDefinitions;

import Pages.LandingPage;
import Pages.ProductScreenPage;
import Pages.SearchResultsPage;
import Utilities.Driver;
import Utilities.PropertiesReader;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.concurrent.TimeUnit;

public class HomePageMouseHoverMenuStepDefinition {

    LandingPage landingPage = new LandingPage();
    ProductScreenPage productScreenPage = new ProductScreenPage();
    SearchResultsPage searchResultsPage = new SearchResultsPage();


//    @Given("User is on sports direct landing page")
//    public void user_is_on_sports_direct_landing_page() throws InterruptedException {
//        Driver.get().get(PropertiesReader.get("url"));
//        Thread.sleep(1000);
//        Assert.assertTrue(Driver.get().getTitle().contains("SportsDirect.com – The UK’s No 1 Sports Retailer"));
//        Driver.get().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
//        landingPage.acceptCookies.click();
//    }

    @When("Users hovers over Mens men and selects clothing option")
    public void users_hovers_over_mens_men_and_selects_clothing_option() {
        Actions action = new Actions(Driver.get());
        WebElement we = Driver.get().findElement(By.id("(//a[contains(text(),'Clothing')])[1]"));
        action.moveToElement(we).moveToElement(Driver.get().findElement(By.xpath("(//a[contains(text(),'Hoodies')])[5]"))).click().build().perform();
    }

    @Then("User should be redirected to Clothing screen")
    public void user_should_be_redirected_to_clothing_screen() {
        Assert.assertTrue(Driver.get().getTitle().contains("Mens Sportswear | Shirts, Hoodies, Joggers | Sports Direct"));
    }



}
