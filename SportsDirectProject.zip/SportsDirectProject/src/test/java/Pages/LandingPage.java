package Pages;

import Utilities.Driver;
import io.cucumber.java.jv.Lan;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class LandingPage {



    public LandingPage()
    {
        PageFactory.initElements(Driver.get(),this);
    }



    @FindBy(id = "lnkTopLevelMenu_2564054")
    public WebElement mensLink;

    @FindBy(xpath = "(//a[contains(text(),'Clothing')])[1]")
    public WebElement clothingLink;

    @FindBy(id = "onetrust-accept-btn-handler")
    public WebElement acceptCookies;

    @FindBy(id = "txtSearch")
    public WebElement searchBox;

    @FindBy(id = "cmdSearch")
    public WebElement searchLogo;


    //lOGIN Journey
    @FindBy(className = "SignInLink")
    public WebElement signInLink;



}
