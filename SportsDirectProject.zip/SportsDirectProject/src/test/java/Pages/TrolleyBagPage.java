package Pages;

import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TrolleyBagPage {

    public TrolleyBagPage()
    {
        PageFactory.initElements(Driver.get(),this);
    }

    @FindBy(xpath = "//span[contains(text(),'Reduce quantity')]")
    public WebElement reduceOrderQuantity;

    @FindBy(xpath = "(//span[contains(text(),'Update')])[1]")
    public WebElement updateBtn;

    @FindBy(xpath = "(//a[@data-action='checkout'])[2]")
    public WebElement continueSecurelyButton;

    @FindBy(xpath = "(//span[contains(text(),'L')])[9]")
    public WebElement shirtSizeLARGE;


    //the next step is results... webdriver should hit the login
    //button.


    //WalletJourney

    @FindBy(className = "deleteItemText")
    public WebElement removeWallet;



}
