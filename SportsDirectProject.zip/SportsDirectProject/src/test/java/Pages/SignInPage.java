package Pages;

import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignInPage {

    public SignInPage()
    {
        PageFactory.initElements(Driver.get(),this);
    }

    @FindBy(xpath = "//input[@name='Login.EmailAddress']")
    public WebElement emailAddress;

    @FindBy(id = "Login_Password")
    public WebElement password;

    @FindBy(id = "LoginButton")
    public WebElement signInButton;









}
