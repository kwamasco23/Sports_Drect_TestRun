package Pages;

import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DeliveryPage {

    public DeliveryPage()
    {
        PageFactory.initElements(Driver.get(),this);
    }

    @FindBy(id = "email")
    public WebElement emailField;

    @FindBy(xpath = "//button[@type='submit']")
    public WebElement continueSecurely;

    @FindBy(xpath = "//a[contains(text(),'No thanks, continue without signing in')]")
    public WebElement continueWithoutSigningIn;

    @FindBy(xpath = "(//div[contains(text(),'Spend over £50 (excluding delivery charge) to get a £5 voucher to spend in-store')])")
    public WebElement collectFromStore;

    @FindBy(xpath = "//button[contains(text(),'Continue')]")
    public WebElement continueDeliveryButton;

    @FindBy(id = "location")
    public WebElement postcodeAddressField;

    @FindBy(xpath = "//button[@type='submit']")
    public WebElement showNearestStores;

    @FindBy(xpath = "(//div[@class='selectionOptions flex flexJustBet'])[3]")
    public WebElement nisaLocalStore;

    @FindBy(xpath = "//button[@type='submit']")
    public WebElement continueBttn2;

    @FindBy(id = "contactNumber")
    public WebElement contactNumberField;

    @FindBy(xpath = "//button[contains(text(),'Continue to Payment')]")
    public WebElement continueToPayment;
















    //input[@id='email']



}
