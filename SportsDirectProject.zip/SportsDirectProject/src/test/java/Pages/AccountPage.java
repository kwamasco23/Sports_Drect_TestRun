package Pages;

import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AccountPage {

    public AccountPage()
    {
        PageFactory.initElements(Driver.get(),this);
    }

    @FindBy(xpath = "(//span[@class='ico'])[1]")
    public WebElement accountICON;

    //Order History Journey
    @FindBy(xpath = "//p[contains(text(),'Review, edit and enquire about your current and recent orders.')]")
    public WebElement orderHistory;

    @FindBy(xpath = "(//a[contains(text(),'View more details')])[2]")
    public WebElement viewMoreDetails;

    @FindBy(id = "btnBackToHistory")
    public WebElement back2HistoryButton;


    //End of Order History journey











}
