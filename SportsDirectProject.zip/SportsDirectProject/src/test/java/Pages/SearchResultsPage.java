package Pages;

import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchResultsPage {

    public SearchResultsPage()
    {
        PageFactory.initElements(Driver.get(),this);
    }

    //Nike Air Max journey
    @FindBy(xpath = "//span[@data-filtername='Mens']")
    public WebElement menCheckBox;

    @FindBy(xpath = "(//span[@class='FirstSelectedFilter SelectedFilter'])[2]")
    public WebElement nikeBrand;

    @FindBy(xpath = "//span[@data-parsedfiltername='9']")
    public WebElement shoeSize9;

    @FindBy(xpath = "(//h3[@class='productFilterTitle'])[1]")
    public WebElement sortByDropDown;

    // UI has been updated and refreshed. New UI nologer has this feature
    @FindBy(xpath = "(//a[@title='Show in four columns'])[1]")
    public WebElement toggleViewSize;

    @FindBy(xpath = "(//a[@title='Page 2'])[1]")
    public WebElement selectResultPage2;

    @FindBy(xpath = "(//span[@class='productdescriptionname'])[6]")
    public WebElement nikeAirMaxSCBlack;

    @FindBy(xpath = "(//span[contains(text(),'Price (Low To High)')])[1]")
    public WebElement lowToHighFilterOption;


    //Adidas tshirt journey

    @FindBy(xpath = "//span[@data-filtername='adidas']")
    public WebElement adidasCheckBox;

    @FindBy(xpath = "//span[@data-filtername='T-Shirts']")
    public WebElement tShirtCheckBox;

    @FindBy(xpath = "(//span[contains(text(),'Core 18 T Shirt Mens')])[2]")
    public WebElement adidasTShirtChosen;


    //wallet

    @FindBy(xpath = "//span[contains(text(),'Hemlock Wallet')]")
    public WebElement hemlockWallet;

    @FindBy(xpath = "(//span[contains(text(),'BOSS')])[3]")
    public WebElement bossWalletProduct;





















}
