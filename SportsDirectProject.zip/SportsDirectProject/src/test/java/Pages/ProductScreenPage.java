package Pages;

import Utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProductScreenPage {


    public ProductScreenPage()
    {
        PageFactory.initElements(Driver.get(),this);
    }

//Nike Air Max Product journey
    @FindBy(xpath = "(//span[contains(text(),'9 (44)')])[1]")
    public WebElement shoeSizeSelection;

    @FindBy(xpath = "//span[@class='prodadd']")
    public WebElement shoeQuantity;

    @FindBy(xpath = "//span[contains(text(),'View Bag')]")
    public WebElement viewBag;

    @FindBy(id = "aAddToBag")
    public WebElement addToBag;


    //Adidas adult tshirt product journey


    //Wallet Journey
    @FindBy(className = "qtybox")
    public WebElement quantityTypeField;

    @FindBy(xpath = "//a[@class='s-basket-plus-button']")
    public WebElement walletQuantityAddButton;

    @FindBy(xpath = "//a[@class='s-basket-minus-button']")
    public WebElement getWalletQuantityRemoveButton;

    @FindBy(xpath = "//a[@class='addToBag']")
    public WebElement AddWalletToToBagButton;

    @FindBy(className = "aAddToBag")
    public WebElement HugoWalletAddToBag;

    @FindBy(xpath = "//span[contains(text(),'Wallets')]")
    public WebElement ReturnToSearchResults;

    @FindBy(xpath = "//span[contains(text(),'6CC Open Holder Wallet')]")
    public WebElement CCOpenHolderWallet;




















}
